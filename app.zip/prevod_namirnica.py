# -*- coding: utf-8 -*-
"""
Prevod namirnica i kategorija.

- U bazi ostaju srpski nazivi (kao do sada).
- Pri prikazu se naziv prevodi na izabrani jezik aplikacije (en / sk / uk).
- Ugradjeni proizvodi i kategorije imaju gotove prevode.
- Kad dodas ili izmenis naziv, on se automatski prevodi (potreban internet)
  i prevodi se pamte u bazi (tabela prevodi_naziva).
- Ako kucas na ukrajinskom/engleskom/slovackom, naziv se pamti kao srpski,
  a tvoj unos se pamti kao prevod za taj jezik.
"""
import json
import threading
import time
import urllib.parse
import urllib.request

from database import db
import prevodi_data

JEZICI = ("en", "sk", "uk")

# _PREVOD[(tip, jezik)][srpski_mala_slova] = prevod
# _OBRNUTO[(tip, jezik)][prevod_mala_slova] = srpski (originalna velika/mala slova)
_PREVOD = {}
_OBRNUTO = {}
_SRPSKI = {"k": set(), "p": set()}  # poznati srpski nazivi (mala slova)
_LOCK = threading.Lock()


# ------------------------------------------------------------------ pomocno
def _jezik():
    try:
        return db.get_setting("jezik", "sr") or "sr"
    except Exception:
        return "sr"


def _upisi(tip, izvor, jezik, prevod, trajno=True):
    """Zapamti prevod u memoriji (i u bazi ako je trajno)."""
    if not izvor or not prevod:
        return
    with _LOCK:
        _PREVOD.setdefault((tip, jezik), {})[izvor.lower()] = prevod
        _OBRNUTO.setdefault((tip, jezik), {})[prevod.lower()] = izvor
        _SRPSKI[tip].add(izvor.lower())
    if trajno:
        try:
            con = db.get_connection()
            con.execute(
                "INSERT OR REPLACE INTO prevodi_naziva (tip, izvor, jezik, prevod) "
                "VALUES (?, ?, ?, ?)",
                (tip, izvor, jezik, prevod),
            )
            con.commit()
            con.close()
        except Exception:
            pass


def _ucitaj():
    # ugradjeni prevodi
    for tip, recnik in (("k", prevodi_data.SEED_K), ("p", prevodi_data.SEED_P)):
        for izvor, po_jeziku in recnik.items():
            for jez, prevod in po_jeziku.items():
                _upisi(tip, izvor, jez, prevod, trajno=False)
    # sacuvani prevodi (korisnicki)
    try:
        con = db.get_connection()
        con.execute(
            "CREATE TABLE IF NOT EXISTS prevodi_naziva ("
            "tip TEXT NOT NULL, izvor TEXT NOT NULL, jezik TEXT NOT NULL, "
            "prevod TEXT NOT NULL, PRIMARY KEY (tip, izvor, jezik))"
        )
        con.commit()
        redovi = con.execute(
            "SELECT tip, izvor, jezik, prevod FROM prevodi_naziva"
        ).fetchall()
        con.close()
        for tip, izvor, jez, prevod in redovi:
            _upisi(tip, izvor, jez, prevod, trajno=False)
    except Exception:
        pass


def prevedi_naziv(naziv, tip, jezik=None):
    """Srpski naziv -> naziv na trazenom jeziku (ili isti ako nema prevoda)."""
    if not isinstance(naziv, str) or not naziv:
        return naziv
    jezik = jezik or _jezik()
    if jezik == "sr":
        return naziv
    p = _PREVOD.get((tip, jezik), {}).get(naziv.lower().strip())
    return p if p else naziv


# ------------------------------------------------------- internet prevodjenje
_CIR_LAT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "ђ": "dj", "е": "e",
    "ж": "z", "з": "z", "и": "i", "ј": "j", "к": "k", "л": "l", "љ": "lj",
    "м": "m", "н": "n", "њ": "nj", "о": "o", "п": "p", "р": "r", "с": "s",
    "т": "t", "ћ": "c", "у": "u", "ф": "f", "х": "h", "ц": "c", "ч": "c",
    "џ": "dz", "ш": "s",
}
_DIJAKRITICI = {
    "č": "c", "ć": "c", "š": "s", "ž": "z", "đ": "dj",
    "Č": "C", "Ć": "C", "Š": "S", "Ž": "Z", "Đ": "Dj",
}


def _u_srpski_latinicu(tekst):
    """Srpska cirilica ili latinica sa dijakriticima -> latinica bez dijakritika."""
    izlaz = []
    for ch in tekst:
        mali = ch.lower()
        if mali in _CIR_LAT:
            izlaz.append(_CIR_LAT[mali])
        elif ch in _DIJAKRITICI:
            izlaz.append(_DIJAKRITICI[ch])
        else:
            izlaz.append(ch)
    rez = "".join(izlaz).strip()
    return rez[:1].upper() + rez[1:].lower() if rez else rez


def _ssl_kontekst():
    import ssl

    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _preuzmi_json(url):
    zahtev = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(zahtev, timeout=5, context=_ssl_kontekst()) as r:
        return json.loads(r.read().decode("utf-8"))


_NEMA_NETA_DO = [0.0]


def prevedi_online(tekst, od, na):
    """Vrati prevod ili None ako internet/servis ne radi."""
    if time.time() < _NEMA_NETA_DO[0]:
        return None
    q = urllib.parse.quote(tekst)
    try:
        podaci = _preuzmi_json(
            "https://translate.googleapis.com/translate_a/single"
            "?client=gtx&sl=%s&tl=%s&dt=t&q=%s" % (od, na, q)
        )
        rez = "".join(deo[0] for deo in podaci[0] if deo and deo[0])
        if rez.strip():
            return rez.strip()
    except Exception:
        pass
    try:
        podaci = _preuzmi_json(
            "https://api.mymemory.translated.net/get?q=%s&langpair=%s|%s"
            % (q, od, na)
        )
        rez = podaci.get("responseData", {}).get("translatedText", "")
        if rez.strip():
            return rez.strip()
    except Exception:
        pass
    _NEMA_NETA_DO[0] = time.time() + 60  # ne pokusavaj opet narednih 60 s
    return None


def _prevedi_na_ostale(tip, srpski, preskoci=None):
    """U pozadini prevedi srpski naziv na sve jezike koje jos nema."""

    def posao():
        for jez in JEZICI:
            if jez == preskoci:
                continue
            if srpski.lower() in _PREVOD.get((tip, jez), {}):
                continue
            p = prevedi_online(srpski, "sr", jez)
            if not p:
                return  # nema interneta - pokusaj opet drugi put
            p = p[:1].upper() + p[1:] if p else p
            _upisi(tip, srpski, jez, p)
            time.sleep(0.2)

    threading.Thread(target=posao, daemon=True).start()


def kanonski(naziv, tip):
    """
    Naziv koji je korisnik uneo -> srpski naziv koji ide u bazu.
    Takodje pokrece automatski prevod na ostale jezike.
    """
    if not isinstance(naziv, str) or not naziv.strip():
        return naziv
    jez = _jezik()
    n = naziv.strip()

    if jez == "sr":
        _upisi_srpski_i_prevedi(tip, n)
        return naziv

    # vec poznat prevod -> vrati srpski original
    srp = _OBRNUTO.get((tip, jez), {}).get(n.lower())
    if srp:
        return srp
    # vec je srpski naziv (npr. staro ime)
    if n.lower() in _SRPSKI[tip]:
        return n

    # nov naziv ukucan na stranom jeziku -> prevedi na srpski
    prevod = prevedi_online(n, jez, "sr")
    if prevod:
        srpski = _u_srpski_latinicu(prevod)
        if srpski:
            _upisi(tip, srpski, jez, n)
            _prevedi_na_ostale(tip, srpski, preskoci=jez)
            return srpski
    # bez interneta: zadrzi kako je ukucano
    _upisi(tip, n, jez, n)
    return n


def _upisi_srpski_i_prevedi(tip, srpski):
    if srpski.lower() in _PREVOD.get((tip, "uk"), {}) and \
            srpski.lower() in _PREVOD.get((tip, "en"), {}) and \
            srpski.lower() in _PREVOD.get((tip, "sk"), {}):
        return
    with _LOCK:
        _SRPSKI[tip].add(srpski.lower())
    _prevedi_na_ostale(tip, srpski)


# ------------------------------------------------- omotaci oko db funkcija
def _prevedi_red(red, kolone, jezik):
    """kolone: lista (indeks, tip). Vraca novi red (tuple)."""
    if red is None:
        return red
    r = list(red)
    for idx, tip in kolone:
        if idx < len(r):
            r[idx] = prevedi_naziv(r[idx], tip, jezik)
    return tuple(r)


def _omotaj_listu(ime, kolone, sortiraj_po=None):
    original = getattr(db, ime)

    def omotac(*args, **kwargs):
        rez = original(*args, **kwargs)
        try:
            jez = _jezik()
            if jez == "sr" or rez is None:
                return rez
            novi = [_prevedi_red(r, kolone, jez) for r in rez]
            if sortiraj_po is not None:
                novi.sort(key=lambda r: str(r[sortiraj_po]).lower())
            return novi
        except Exception:
            return rez

    setattr(db, ime, omotac)


def _omotaj_jedan(ime, kolone):
    original = getattr(db, ime)

    def omotac(*args, **kwargs):
        rez = original(*args, **kwargs)
        try:
            jez = _jezik()
            if jez == "sr" or rez is None:
                return rez
            return _prevedi_red(rez, kolone, jez)
        except Exception:
            return rez

    setattr(db, ime, omotac)


def _omotaj_kategorija_naziv():
    original = db.get_kategorija_naziv

    def omotac(*args, **kwargs):
        rez = original(*args, **kwargs)
        try:
            if isinstance(rez, str):
                return prevedi_naziv(rez, "k")
            if isinstance(rez, (tuple, list)) and rez and isinstance(rez[0], str):
                return (prevedi_naziv(rez[0], "k"),) + tuple(rez[1:])
        except Exception:
            pass
        return rez

    db.get_kategorija_naziv = omotac


def _omotaj_pisanje(ime, indeks, kljuc, tip):
    """Pre upisa pretvori naziv u srpski i pokreni prevod na ostale jezike."""
    original = getattr(db, ime)

    def omotac(*args, **kwargs):
        try:
            if kljuc in kwargs:
                kwargs[kljuc] = kanonski(kwargs[kljuc], tip)
            elif len(args) > indeks:
                args = list(args)
                args[indeks] = kanonski(args[indeks], tip)
                args = tuple(args)
        except Exception:
            pass
        return original(*args, **kwargs)

    setattr(db, ime, omotac)


def _omotaj_pretragu():
    original = db.search_proizvodi

    def omotac(query, limit=10, *args, **kwargs):
        jez = _jezik()
        if jez == "sr":
            return original(query, limit, *args, **kwargs)
        try:
            q = (query or "").strip().lower()
            # srpski nazivi ciji prevod sadrzi trazeni tekst
            pogodjeni = set(
                srp
                for srp, prev in list(_PREVOD.get(("p", jez), {}).items())
                if q in prev.lower()
            )
            con = db.get_connection()
            try:
                redovi = con.execute(
                    "SELECT id, naziv, jedinica_mere, zadnja_cena FROM proizvodi"
                ).fetchall()
            finally:
                con.close()
            rezultat = []
            for red in redovi:
                naziv = red[1] or ""
                if naziv.lower() in pogodjeni or q in naziv.lower():
                    rezultat.append(_prevedi_red(red, [(1, "p")], jez))
            rezultat.sort(key=lambda r: str(r[1]).lower())
            return rezultat[: int(limit)] if limit else rezultat
        except Exception:
            return original(query, limit, *args, **kwargs)

    db.search_proizvodi = omotac


# ----------------------------------------------- prevod starih (ranijih) unosa
def _dopuni_stare_unose():
    """U pozadini prevedi nazive koje je korisnik ranije uneo (treba internet)."""
    time.sleep(8)
    try:
        con = db.get_connection()
        proizvodi = [r[0] for r in con.execute("SELECT DISTINCT naziv FROM proizvodi")]
        kategorije = [r[0] for r in con.execute("SELECT DISTINCT naziv FROM kategorije")]
        con.close()
    except Exception:
        return
    broj = 0
    for tip, nazivi in (("k", kategorije), ("p", proizvodi)):
        for naziv in nazivi:
            if not naziv:
                continue
            for jez in JEZICI:
                if naziv.lower() in _PREVOD.get((tip, jez), {}):
                    continue
                p = prevedi_online(naziv, "sr", jez)
                if not p:
                    return  # nema interneta
                p = p[:1].upper() + p[1:]
                _upisi(tip, naziv, jez, p)
                broj += 1
                time.sleep(0.3)
                if broj >= 90:
                    return


# ------------------------------------------------------------------ primena
def primeni():
    _ucitaj()

    # prikaz (citanje)
    _omotaj_listu("get_kategorije", [(1, "k")], sortiraj_po=1)
    _omotaj_kategorija_naziv()
    _omotaj_listu("get_proizvodi_sa_prodavnicom", [(1, "p")], sortiraj_po=1)
    _omotaj_listu(
        "get_proizvodi_puno", [(1, "p"), (7, "k"), (9, "k")], sortiraj_po=1
    )
    _omotaj_jedan("get_proizvod_puno", [(1, "p"), (7, "k"), (9, "k")])
    _omotaj_listu("get_proizvodi_po_kategoriji", [(1, "p")], sortiraj_po=1)
    _omotaj_listu("get_stavke_sa_id", [(1, "p")])
    _omotaj_listu("get_lista_stavke", [(0, "p")])
    _omotaj_pretragu()

    # upis (cuvanje)
    _omotaj_pisanje("add_or_update_proizvod", 0, "naziv", "p")
    _omotaj_pisanje("update_proizvod", 1, "naziv", "p")
    _omotaj_pisanje("add_kategorija", 0, "naziv", "k")
    _omotaj_pisanje("update_kategorija", 1, "novi_naziv", "k")
    _omotaj_pisanje("add_stavka", 2, "naziv", "p")

    threading.Thread(target=_dopuni_stare_unose, daemon=True).start()
