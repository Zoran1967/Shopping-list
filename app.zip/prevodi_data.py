# -*- coding: utf-8 -*-
"""
Ugradjeni prevodi kategorija i namirnica (srpski -> engleski | slovacki | ukrajinski).
Format: srpski | en | sk | uk
"""

KATEGORIJE = """
Pekara - peciva | Bakery - pastries | Pekáreň - pečivo | Пекарня - випічка
Hleb | Bread | Chlieb | Хліб
Meso | Meat | Mäso | М'ясо
Suhomesnato | Cured meats | Údeniny | В'ялені м'ясні вироби
Riba | Fish | Ryby | Риба
Konzervirana riba | Canned fish | Konzervované ryby | Консервована риба
Mlecni proizvodi | Dairy products | Mliečne výrobky | Молочні продукти
Jaja | Eggs | Vajcia | Яйця
Sveze povrce | Fresh vegetables | Čerstvá zelenina | Свіжі овочі
Sveze voce | Fresh fruit | Čerstvé ovocie | Свіжі фрукти
Salate | Salads | Šaláty | Салати
Konzervirano povrce | Canned vegetables | Konzervovaná zelenina | Консервовані овочі
Konzervirano voce | Canned fruit | Konzervované ovocie | Консервовані фрукти
Smrznuti proizvodi | Frozen products | Mrazené výrobky | Заморожені продукти
Testenina | Pasta | Cestoviny | Макаронні вироби
Pirinac i zitarice | Rice and cereals | Ryža a obilniny | Рис і крупи
Brasno i secer | Flour and sugar | Múka a cukor | Борошно і цукор
Ulje i sirce | Oil and vinegar | Olej a ocot | Олія та оцет
Zacini | Spices | Korenie | Спеції
Slatkisi | Sweets | Sladkosti | Солодощі
Grickalice | Snacks | Pochutiny | Снеки
Pica | Drinks | Nápoje | Напої
Decija hrana | Baby food | Detská výživa | Дитяче харчування
Hrana za kucne ljubimce | Pet food | Krmivo pre domáce zvieratá | Корм для домашніх тварин
Higijena | Hygiene | Hygiena | Гігієна
Kucna hemija | Household chemicals | Domáca chémia | Побутова хімія
"""

PROIZVODI = """
Kifla | Crescent roll | Rožok | Ріжок
Slana kifla | Salted roll | Slaný rožok | Солоний ріжок
Puter kifla | Butter roll | Maslový rožok | Вершковий ріжок
Integralna kifla | Whole grain roll | Celozrnný rožok | Цільнозерновий ріжок
Kroasan | Croissant | Croissant | Круасан
Kroasan sa cokoladom | Chocolate croissant | Čokoládový croissant | Круасан із шоколадом
Kroasan sa sirom | Cheese croissant | Croissant so syrom | Круасан із сиром
Pereca | Pretzel | Praclík | Крендель
Zu-zu | Zu-zu | Zu-zu | Зу-зу
Pogacica sa sirom | Cheese biscuit | Pogačka so syrom | Погачиця з сиром
Pogacica sa cvarcima | Cracklin biscuit | Pogačka so škvarkami | Погачиця зі шкварками
Stapici | Bread sticks | Tyčinky | Палички
Burek sa sirom | Cheese burek | Burek so syrom | Бурек із сиром
Burek sa mesom | Meat burek | Burek s mäsom | Бурек з м'ясом
Burek sa krompirom | Potato burek | Burek so zemiakmi | Бурек з картоплею
Pizza parce | Pizza slice | Kúsok pizze | Шматок піци
Beli hleb | White bread | Biely chlieb | Білий хліб
Polubeli hleb | Semi-white bread | Polobiely chlieb | Напівбілий хліб
Razani hleb | Rye bread | Ražný chlieb | Житній хліб
Integralni hleb | Whole grain bread | Celozrnný chlieb | Цільнозерновий хліб
Kukuruzni hleb | Corn bread | Kukuričný chlieb | Кукурудзяний хліб
Heljdin hleb | Buckwheat bread | Pohánkový chlieb | Гречаний хліб
Tost hleb | Toast bread | Toastový chlieb | Хліб для тостів
Bezglutenski hleb | Gluten-free bread | Bezlepkový chlieb | Безглютеновий хліб
Lepinja | Lepinja flatbread | Lepinja | Лепіня
Piletina file | Chicken fillet | Kuracie filé | Куряче філе
Pileci batak | Chicken drumstick | Kuracie stehno | Куряче стегно
Pileca krilca | Chicken wings | Kuracie krídla | Курячі крильця
Curetina | Turkey meat | Morčacie mäso | М'ясо індички
Svinjski but | Pork leg | Bravčové stehno | Свинячий окіст
Svinjski vrat | Pork neck | Bravčová krkovička | Свиняча шия
Svinjska plecka | Pork shoulder | Bravčové pliecko | Свиняча лопатка
Juneci but | Beef leg | Hovädzie stehno | Яловичий окіст
Mleveno meso | Minced meat | Mleté mäso | М'ясний фарш
Teletina | Veal | Teľacina | Телятина
Jagnjetina | Lamb | Jahňacina | Ягнятина
Sunka | Ham | Šunka | Шинка
Prsuta | Dry-cured ham | Sušená šunka | В'ялена шинка
Pecenica | Smoked pork loin | Údená krkovička | Копчена свинина
Kulen | Kulen sausage | Kulen (klobása) | Кулен (ковбаса)
Cajna kobasica | Tea sausage | Čajová klobása | Чайна ковбаса
Zimska salama | Winter salami | Zimná saláma | Зимова салямі
Mortadela | Mortadella | Mortadela | Мортадела
Slanina | Bacon | Slanina | Бекон
Virsle | Frankfurters | Párky | Сосиски
Losos | Salmon | Losos | Лосось
Pastrmka | Trout | Pstruh | Форель
Oslic | Hake | Merlúza | Хек
Saran | Carp | Kapor | Короп
Sardina | Sardine | Sardinka | Сардина
Tuna | Tuna | Tuniak | Тунець
Skusa | Mackerel | Makrela | Скумбрія
Fileti ribe | Fish fillets | Rybacie filé | Рибне філе
Smrznuta riba | Frozen fish | Mrazená ryba | Заморожена риба
Tuna u komadima | Tuna chunks | Tuniak v kúskoch | Тунець шматками
Tuna komadici | Tuna pieces | Kúsky tuniaka | Тунець у шматочках
Sardina konzerva | Canned sardines | Sardinky v konzerve | Сардини консервовані
Skusa konzerva | Canned mackerel | Makrela v konzerve | Скумбрія консервована
Pasteta od tune | Tuna pate | Tuniaková nátierka | Паштет із тунця
Mleko | Milk | Mlieko | Молоко
Jogurt | Yogurt | Jogurt | Йогурт
Kefir | Kefir | Kefír | Кефір
Kiselo mleko | Sour milk | Kyslé mlieko | Кисле молоко
Pavlaka | Cream | Smotana | Вершки
Kisela pavlaka | Sour cream | Kyslá smotana | Сметана
Maslac | Butter | Maslo | Вершкове масло
Margarin | Margarine | Margarín | Маргарин
Mladi sir | Fresh cheese | Čerstvý syr | Свіжий сир
Trapist | Trappist cheese | Trapista | Сир трапіст
Kackavalj | Kashkaval cheese | Kačkaval | Качкавал
Mocarela | Mozzarella | Mozzarella | Моцарела
Feta sir | Feta cheese | Feta syr | Сир фета
Jaja | Eggs | Vajcia | Яйця
Krompir | Potatoes | Zemiaky | Картопля
Crni luk | Onion | Cibuľa | Цибуля
Beli luk | Garlic | Cesnak | Часник
Sargarepa | Carrot | Mrkva | Морква
Paprika | Pepper | Paprika | Перець
Paradajz | Tomato | Paradajka | Помідор
Krastavac | Cucumber | Uhorka | Огірок
Tikvice | Zucchini | Cuketa | Кабачки
Patlidzan | Eggplant | Baklažán | Баклажан
Kupus | Cabbage | Kapusta | Капуста
Karfiol | Cauliflower | Karfiol | Цвітна капуста
Brokoli | Broccoli | Brokolica | Броколі
Zelena salata | Lettuce | Hlávkový šalát | Салат-латук
Spanac | Spinach | Špenát | Шпинат
Cvekla | Beetroot | Cvikla | Буряк
Rotkvica | Radish | Reďkovka | Редиска
Celer | Celery | Zeler | Селера
Persun | Parsley | Petržlen | Петрушка
Jabuka | Apple | Jablko | Яблуко
Kruska | Pear | Hruška | Груша
Banana | Banana | Banán | Банан
Pomorandza | Orange | Pomaranč | Апельсин
Mandarina | Tangerine | Mandarínka | Мандарин
Limun | Lemon | Citrón | Лимон
Grejp | Grapefruit | Grapefruit | Грейпфрут
Kivi | Kiwi | Kiwi | Ківі
Breskva | Peach | Broskyňa | Персик
Kajsija | Apricot | Marhuľa | Абрикос
Sljiva | Plum | Slivka | Слива
Tresnja | Sweet cherry | Čerešňa | Черешня
Visnja | Sour cherry | Višňa | Вишня
Jagoda | Strawberry | Jahoda | Полуниця
Malina | Raspberry | Malina | Малина
Borovnica | Blueberry | Čučoriedka | Чорниця
Grozdje | Grapes | Hrozno | Виноград
Lubenica | Watermelon | Vodový melón | Кавун
Dinja | Melon | Melón | Диня
Zelena salata gotova | Ready green salad | Hotový zelený šalát | Готовий зелений салат
Kupus salata | Cabbage salad | Kapustový šalát | Салат із капусти
Paradajz salata | Tomato salad | Paradajkový šalát | Салат із помідорів
Sopska salata | Shopska salad | Šopský šalát | Шопський салат
Ruska salata | Russian salad | Ruský šalát | Російський салат
Mimoza salata | Mimosa salad | Šalát Mimóza | Салат «Мімоза»
Cvekla salata | Beetroot salad | Cviklový šalát | Салат із буряка
Grasak konzerva | Canned peas | Hrášok v konzerve | Горошок консервований
Kukuruz konzerva | Canned corn | Kukurica v konzerve | Кукурудза консервована
Pasulj konzerva | Canned beans | Fazuľa v konzerve | Квасоля консервована
Boranija konzerva | Canned green beans | Zelená fazuľka v konzerve | Стручкова квасоля консервована
Paradajz pelat | Peeled tomatoes | Lúpané paradajky | Очищені помідори
Paradajz pire | Tomato puree | Paradajkové pyré | Томатне пюре
Ajvar | Ajvar | Ajvar | Айвар
Pindjur | Pindjur | Pindjur | Пінджур
Kiseli krastavci | Pickles | Kyslé uhorky | Солоні огірки
Feferoni | Pickled peppers | Feferóny | Мариновані перчики
Masline | Olives | Olivy | Оливки
Cvekla konzerva | Canned beetroot | Cvikla v konzerve | Буряк консервований
Ananas konzerva | Canned pineapple | Ananás v konzerve | Ананас консервований
Breskva konzerva | Canned peaches | Broskyne v konzerve | Персики консервовані
Kruska konzerva | Canned pears | Hrušky v konzerve | Груші консервовані
Vocni koktel | Fruit cocktail | Ovocný koktail | Фруктовий коктейль
Kompot od visanja | Sour cherry compote | Višňový kompót | Компот із вишні
Kompot od sljiva | Plum compote | Slivkový kompót | Компот зі сливи
Pomfrit | French fries | Hranolky | Картопля фрі
Grasak smrznuti | Frozen peas | Mrazený hrášok | Заморожений горошок
Boranija smrznuta | Frozen green beans | Mrazená zelená fazuľka | Заморожена стручкова квасоля
Mesano povrce smrznuto | Frozen mixed vegetables | Mrazená zeleninová zmes | Заморожена овочева суміш
Brokoli smrznuti | Frozen broccoli | Mrazená brokolica | Заморожена броколі
Karfiol smrznuti | Frozen cauliflower | Mrazený karfiol | Заморожена цвітна капуста
Pica smrznuta | Frozen pizza | Mrazená pizza | Заморожена піца
Sladoled | Ice cream | Zmrzlina | Морозиво
Spagete | Spaghetti | Špagety | Спагеті
Makarone | Macaroni | Makaróny | Макарони
Penne | Penne | Penne | Пенне
Fusili | Fusilli | Fusilli | Фузілі
Rezanci | Noodles | Rezance | Локшина
Kore za pitu | Pie dough sheets | Cesto na koláč | Коржі для пирога
Beli pirinac | White rice | Biela ryža | Білий рис
Integralni pirinac | Brown rice | Hnedá ryža | Бурий рис
Basmati | Basmati rice | Ryža basmati | Рис басматі
Palenta | Polenta | Polenta | Полента
Ovsene pahuljice | Oat flakes | Ovsené vločky | Вівсяні пластівці
Musli | Muesli | Müsli | Мюслі
Belo brasno | White flour | Biela múka | Пшеничне борошно
Integralno brasno | Whole grain flour | Celozrnná múka | Цільнозернове борошно
Kukuruzno brasno | Corn flour | Kukuričná múka | Кукурудзяне борошно
Secer | Sugar | Cukor | Цукор
Smedji secer | Brown sugar | Hnedý cukor | Коричневий цукор
Secer u prahu | Powdered sugar | Práškový cukor | Цукрова пудра
Suncokretovo ulje | Sunflower oil | Slnečnicový olej | Соняшникова олія
Maslinovo ulje | Olive oil | Olivový olej | Оливкова олія
Sirce alkoholno | Spirit vinegar | Liehový ocot | Спиртовий оцет
Jabukovo sirce | Apple cider vinegar | Jablčný ocot | Яблучний оцет
Balzamiko | Balsamic vinegar | Balzamikový ocot | Бальзамічний оцет
So | Salt | Soľ | Сіль
Biber | Black pepper | Čierne korenie | Чорний перець
Vegeta | Vegeta seasoning | Vegeta (korenie) | Вегета (приправа)
Aleva paprika | Ground paprika | Mletá paprika | Мелена паприка
Origano | Oregano | Oregano | Орегано
Bosiljak | Basil | Bazalka | Базилік
Persun suvi | Dried parsley | Sušená petržlenová vňať | Сушена петрушка
Beli luk u prahu | Garlic powder | Cesnak mletý | Часниковий порошок
Kari | Curry | Kari | Каррі
Cimet | Cinnamon | Škorica | Кориця
Cokolada | Chocolate | Čokoláda | Шоколад
Keks | Biscuits | Keksy | Печиво
Napolitanke | Wafers | Oblátky | Вафлі
Bombone | Candies | Cukríky | Цукерки
Zvake | Chewing gum | Žuvačky | Жуйки
Med | Honey | Med | Мед
Dzem | Jam | Džem | Джем
Krem | Cream spread | Krémová nátierka | Кремова паста
Cips | Chips | Čipsy | Чіпси
Smoki | Smoki snack | Smoki | Смокі
Kokice | Popcorn | Popcorn | Попкорн
Stapici slani | Salty sticks | Slané tyčinky | Солоні палички
Tortilja cips | Tortilla chips | Tortilla čipsy | Чіпси тортилья
Kikiriki | Peanuts | Arašidy | Арахіс
Badem | Almonds | Mandle | Мигдаль
Lesnik | Hazelnuts | Lieskové orechy | Фундук
Voda | Water | Voda | Вода
Mineralna voda | Mineral water | Minerálna voda | Мінеральна вода
Sok | Juice | Džús | Сік
Gazirani sok | Soda | Šumivý nápoj | Газований напій
Ledeni caj | Iced tea | Ľadový čaj | Холодний чай
Energetsko pice | Energy drink | Energetický nápoj | Енергетичний напій
Kafa | Coffee | Káva | Кава
Instant kafa | Instant coffee | Instantná káva | Розчинна кава
Crni caj | Black tea | Čierny čaj | Чорний чай
Zeleni caj | Green tea | Zelený čaj | Зелений чай
Kakao | Cocoa | Kakao | Какао
Kasice | Baby porridge | Detské kašičky | Дитячі кашки
Adaptirano mleko | Infant formula | Dojčenské mlieko | Дитяча молочна суміш
Kase | Porridges | Kaše | Каші
Keksi za bebe | Baby biscuits | Detské keksy | Дитяче печиво
Hrana za pse | Dog food | Krmivo pre psov | Корм для собак
Hrana za macke | Cat food | Krmivo pre mačky | Корм для котів
Poslastice za ljubimce | Pet treats | Maškrty pre zvieratá | Ласощі для тварин
Pesak za macke | Cat litter | Podstielka pre mačky | Наповнювач для котячого туалету
Toalet papir | Toilet paper | Toaletný papier | Туалетний папір
Papirni ubrusi | Paper towels | Papierové utierky | Паперові рушники
Salvete | Napkins | Obrúsky | Серветки
Vlazne maramice | Wet wipes | Vlhčené obrúsky | Вологі серветки
Sapun | Soap | Mydlo | Мило
Sampon | Shampoo | Šampón | Шампунь
Gel za tusiranje | Shower gel | Sprchovací gél | Гель для душу
Pasta za zube | Toothpaste | Zubná pasta | Зубна паста
Cetkica za zube | Toothbrush | Zubná kefka | Зубна щітка
Dezodorans | Deodorant | Dezodorant | Дезодорант
Brijaci | Razors | Žiletky | Бритви
Prasak za ves | Laundry detergent | Prací prášok | Пральний порошок
Tecni deterdzent | Liquid detergent | Tekutý prací prostriedok | Рідкий засіб для прання
Omeksivac | Fabric softener | Aviváž | Кондиціонер для білизни
Deterdzent za sudove | Dish soap | Prostriedok na riad | Засіб для миття посуду
Tablete za sudomasinu | Dishwasher tablets | Tablety do umývačky | Таблетки для посудомийки
Sredstvo za staklo | Glass cleaner | Čistič skla | Засіб для скла
Sredstvo za kupatilo | Bathroom cleaner | Čistič kúpeľne | Засіб для ванної
Izbeljivac | Bleach | Bielidlo | Відбілювач
Sredstvo za pod | Floor cleaner | Čistič podláh | Засіб для підлоги
Sundjeri | Sponges | Špongie | Губки
Kese za smece | Trash bags | Vrecia na odpad | Пакети для сміття
"""


def _parse(blok):
    izlaz = {}
    for red in blok.strip().splitlines():
        delovi = [d.strip() for d in red.split("|")]
        if len(delovi) == 4 and delovi[0]:
            izlaz[delovi[0]] = {"en": delovi[1], "sk": delovi[2], "uk": delovi[3]}
    return izlaz


SEED_K = _parse(KATEGORIJE)
SEED_P = _parse(PROIZVODI)
