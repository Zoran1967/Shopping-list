"""
Pokretac za Soping Lista.

Sakriva Android navigacionu traku (dugmad za nazad/home/nedavne) i zatim
pokrece originalnu aplikaciju (app_main.pyc).
Traka se vraca prevlacenjem od donje ivice ekrana i opet se sama sakrije.
"""
import os
import runpy
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)


def _sakrij_navigaciju(*_args):
    try:
        from jnius import autoclass
        from android.runnable import run_on_ui_thread
    except Exception:
        return  # nismo na Androidu

    @run_on_ui_thread
    def _ui():
        try:
            activity = autoclass("org.kivy.android.PythonActivity").mActivity
            view = autoclass("android.view.View")
            decor = activity.getWindow().getDecorView()
            flags = (
                view.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | view.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | view.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | view.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
            decor.setSystemUiVisibility(flags)
        except Exception:
            pass
        try:
            decor = activity.getWindow().getDecorView()
            ctrl = decor.getWindowInsetsController()
            if ctrl is not None:
                insets_type = autoclass("android.view.WindowInsets$Type")
                ctrl.hide(insets_type.navigationBars())
                ctrl.setSystemBarsBehavior(2)
        except Exception:
            pass

    _ui()


try:
    from kivy.clock import Clock
    Clock.schedule_once(_sakrij_navigaciju, 0.5)
    # ponovo ga sakrij ako se vrati (npr. posle povratka u aplikaciju)
    Clock.schedule_interval(_sakrij_navigaciju, 2)
except Exception:
    pass

runpy.run_path(os.path.join(BASE_DIR, "app_main.pyc"), run_name="__main__")
