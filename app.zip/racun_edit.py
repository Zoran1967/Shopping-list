"""
Izmena sacuvanih racuna (istorija kupovina).

Dodirni stavku na racunu da ispravis kolicinu ili cenu, ili da je obrises.
Ukupan iznos racuna se sam preracuna i sacuva.

Ovaj modul zamenjuje HistoryScreen.open_receipt_detail (poziva ga main.py).
"""
from kivy.graphics import Color, RoundedRectangle
from kivy.metrics import dp
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView

from database import db
import pdf_export
from translations import prevedi
from widgets import (
    DangerButton,
    PrimaryButton,
    SecondaryButton,
    StyledTextInput,
)

# Sirine kolona: proizvod, kolicina, cena, ukupno
KOLONE = (0.40, 0.14, 0.23, 0.23)

_NAPOMENA = {
    "sr": "Dodirni stavku da je ispravis ili obrises",
    "en": "Tap an item to correct or delete it",
    "sk": "Ťuknite na položku pre úpravu alebo vymazanie",
    "uk": "Торкніться позиції, щоб виправити або видалити",
}


def _jezik():
    try:
        return db.get_setting("jezik", "sr")
    except Exception:
        return "sr"


def _t(kljuc, **kw):
    s = prevedi(kljuc, _jezik())
    if kw:
        try:
            return s.format(**kw)
        except Exception:
            return s
    return s


def _kol(v):
    try:
        return "{:g}".format(float(v))
    except Exception:
        return str(v)


def _cena(v_rsd):
    return "{:.2f}".format(db.rsd_u_prikaz(v_rsd))


def _broj(tekst):
    return float(str(tekst).replace(",", ".").strip())


class RedStavke(ButtonBehavior, BoxLayout):
    """Jedan red na racunu; moze da se dodirne."""

    def __init__(self, vrednosti, **kwargs):
        super().__init__(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(54),
            **kwargs
        )
        with self.canvas.before:
            Color(0.17, 0.17, 0.2, 1)
            self._pozadina = RoundedRectangle(
                pos=self.pos, size=self.size, radius=[dp(8)]
            )
        self.bind(pos=self._osvezi, size=self._osvezi)
        for tekst, sirina in zip(vrednosti, KOLONE):
            lab = Label(
                text=str(tekst),
                size_hint_x=sirina,
                font_size="14sp",
                halign="center",
                valign="middle",
            )
            lab.bind(size=lambda inst, val: setattr(inst, "text_size", val))
            self.add_widget(lab)

    def _osvezi(self, *_):
        self._pozadina.pos = self.pos
        self._pozadina.size = self.size


def _zaglavlje_lab(tekst, sirina):
    lab = Label(
        text=tekst,
        size_hint_x=sirina,
        font_size="12sp",
        bold=True,
        halign="center",
        valign="middle",
    )
    lab.bind(size=lambda inst, val: setattr(inst, "text_size", val))
    return lab


def otvori_racun(
    self,
    lista_id,
    datum,
    ukupno_rsd,
    prodavnica_naziv,
    parent_popup,
    refresh_parent,
):
    oznaka = db.valuta_oznaka()

    root = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(4))

    root.add_widget(
        Label(
            text=str(datum),
            font_size="20sp",
            bold=True,
            size_hint_y=None,
            height=dp(36),
        )
    )

    root.add_widget(
        Label(
            text=_NAPOMENA.get(_jezik(), _NAPOMENA["en"]),
            font_size="12sp",
            color=(0.7, 0.7, 0.75, 1),
            size_hint_y=None,
            height=dp(22),
        )
    )

    zaglavlje = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(40))
    nazivi_kolona = (
        _t("hist_col_product"),
        _t("hist_col_qty"),
        _t("hist_col_price", valuta=oznaka),
        _t("hist_col_total"),
    )
    for tekst, sirina in zip(nazivi_kolona, KOLONE):
        zaglavlje.add_widget(_zaglavlje_lab(tekst, sirina))
    root.add_widget(zaglavlje)

    scroll = ScrollView()
    lista = GridLayout(cols=1, size_hint_y=None, spacing=dp(4))
    lista.bind(minimum_height=lista.setter("height"))
    scroll.add_widget(lista)
    root.add_widget(scroll)

    ukupno_lab = Label(
        text="",
        font_size="20sp",
        bold=True,
        size_hint_y=None,
        height=dp(44),
    )
    root.add_widget(ukupno_lab)

    status = Label(
        text="",
        font_size="12sp",
        size_hint_y=None,
        height=dp(0),
        halign="center",
        valign="middle",
    )
    status.bind(size=lambda inst, val: setattr(inst, "text_size", (val[0], None)))
    root.add_widget(status)

    pdf_dugme = PrimaryButton(
        text=_t("hist_print_btn"), size_hint_y=None, height=dp(48)
    )
    root.add_widget(pdf_dugme)

    donji = BoxLayout(
        orientation="horizontal", size_hint_y=None, height=dp(48), spacing=dp(8)
    )
    nazad = SecondaryButton(text=_t("hist_back"))
    obrisi = DangerButton(text=_t("hist_delete_receipt"))
    donji.add_widget(nazad)
    donji.add_widget(obrisi)
    root.add_widget(donji)

    popup = Popup(
        title=_t("hist_receipt_popup_title"),
        content=root,
        size_hint=(0.96, 0.92),
        auto_dismiss=False,
    )

    # ---------------------------------------------------------------- stavke
    def osvezi():
        lista.clear_widgets()
        redovi = db.get_stavke_sa_id(lista_id)
        ukupno = 0.0
        for stavka in redovi:
            sid, naziv, kolicina, cena, total, _pid = stavka
            ukupno += float(total)
            red = RedStavke(
                [naziv, _kol(kolicina), _cena(cena), _cena(total)]
            )
            red.bind(on_release=lambda inst, s=stavka: izmeni(s))
            lista.add_widget(red)
        ukupno_lab.text = "{} {:.2f} {}".format(
            _t("hist_total_label"), db.rsd_u_prikaz(ukupno), oznaka
        )

    def posle_izmene():
        redovi = db.get_stavke_sa_id(lista_id)
        if not redovi:
            # racun bez stavki nema smisla - obrisi ga
            db.delete_lista(lista_id)
            popup.dismiss()
            refresh_parent()
            return
        ukupno = sum(float(r[4]) for r in redovi)
        db.close_lista(lista_id, ukupno)
        osvezi()
        try:
            refresh_parent()
        except Exception:
            pass

    def izmeni(stavka):
        sid, naziv, kolicina, cena, total, _pid = stavka

        sadrzaj = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(8))
        sadrzaj.add_widget(
            Label(
                text=str(naziv),
                font_size="18sp",
                bold=True,
                size_hint_y=None,
                height=dp(40),
            )
        )

        sadrzaj.add_widget(
            Label(
                text=_t("sl_qty_hint"),
                font_size="14sp",
                size_hint_y=None,
                height=dp(22),
            )
        )
        polje_kol = StyledTextInput(
            text=_kol(kolicina),
            multiline=False,
            input_type="number",
            size_hint_y=None,
            height=dp(48),
            font_size="18sp",
        )
        sadrzaj.add_widget(polje_kol)

        sadrzaj.add_widget(
            Label(
                text=_t("sl_price_hint", valuta=oznaka),
                font_size="14sp",
                size_hint_y=None,
                height=dp(22),
            )
        )
        polje_cena = StyledTextInput(
            text=_cena(cena),
            multiline=False,
            input_type="number",
            size_hint_y=None,
            height=dp(48),
            font_size="18sp",
        )
        sadrzaj.add_widget(polje_cena)

        greska = Label(
            text="",
            color=(1, 0.4, 0.4, 1),
            font_size="14sp",
            size_hint_y=None,
            height=dp(24),
        )
        sadrzaj.add_widget(greska)

        sacuvaj_d = PrimaryButton(
            text=_t("sl_save"), size_hint_y=None, height=dp(48)
        )
        sadrzaj.add_widget(sacuvaj_d)

        red_dugmad = BoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(48),
            spacing=dp(8),
        )
        otkazi_d = SecondaryButton(text=_t("sl_cancel"))
        obrisi_d = DangerButton(text=_t("sl_delete_item_btn"))
        red_dugmad.add_widget(otkazi_d)
        red_dugmad.add_widget(obrisi_d)
        sadrzaj.add_widget(red_dugmad)
        sadrzaj.add_widget(Label())  # popuna

        dijalog = Popup(
            title=_t("sl_item_edit_title"),
            content=sadrzaj,
            size_hint=(0.92, None),
            height=dp(470),
            auto_dismiss=False,
        )

        def sacuvaj(*_):
            try:
                k = _broj(polje_kol.text)
                c = _broj(polje_cena.text)
                if k <= 0 or c < 0:
                    raise ValueError
            except Exception:
                greska.text = _t("db_err_bad_price")
                return
            db.update_stavka(sid, k, db.prikaz_u_rsd(c))
            dijalog.dismiss()
            posle_izmene()

        stanje = {"potvrda": False}

        def obrisi_stavku(inst):
            if not stanje["potvrda"]:
                stanje["potvrda"] = True
                inst.text = _t("sl_confirm_delete_item")
                return
            db.delete_stavka(sid)
            dijalog.dismiss()
            posle_izmene()

        sacuvaj_d.bind(on_release=sacuvaj)
        otkazi_d.bind(on_release=lambda *_: dijalog.dismiss())
        obrisi_d.bind(on_release=obrisi_stavku)
        dijalog.open()

    # ------------------------------------------------------------- dugmad
    def izvezi_pdf(*_):
        try:
            redovi = db.get_lista_stavke(lista_id)
            stavke = [
                (r[0], r[1], db.rsd_u_prikaz(r[2]), db.rsd_u_prikaz(r[3]))
                for r in redovi
            ]
            ukupno = sum(float(r[3]) for r in redovi)
            putanja = pdf_export.generisi_racun_pdf(
                prodavnica_naziv,
                datum,
                stavke,
                db.rsd_u_prikaz(ukupno),
                oznaka,
            )
            poruka = _t("hist_pdf_saved_msg", putanja=putanja)
        except Exception as e:
            poruka = _t("hist_pdf_error_msg", greska=str(e))
        status.text = poruka
        status.height = dp(52)

    stanje_brisanja = {"potvrda": False}

    def obrisi_racun(inst):
        if not stanje_brisanja["potvrda"]:
            stanje_brisanja["potvrda"] = True
            inst.text = _t("hist_confirm_delete")
            return
        db.delete_lista(lista_id)
        popup.dismiss()
        refresh_parent()

    pdf_dugme.bind(on_release=izvezi_pdf)
    nazad.bind(on_release=lambda *_: popup.dismiss())
    obrisi.bind(on_release=obrisi_racun)

    osvezi()
    popup.open()


def primeni():
    """Zameni originalni prikaz racuna ovim koji dozvoljava izmene."""
    import screens.history_screen as hs

    hs.HistoryScreen.open_receipt_detail = otvori_racun
